This is a build of the experimental version of my emu in steamclient mode with an included loader. See both the regular and experimental readmes for how to configure it.
Note that all emu config files should be put beside the steamclient dll. You do not need to put a steam_interfaces.txt file for the steamclient version of the emu.

To use the loader, put both steamclient dlls and the loader in a folder and edit the config file. Make sure you put the right appid in the ini file.
